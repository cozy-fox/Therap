var priority={};
priority['plus']     = 0;
priority['minus']    = 0;
priority['multiply'] = 0;
priority['division'] = 0;

var correspondingChar={};
correspondingChar['plus']     = '+';
correspondingChar['minus']    = '-';
correspondingChar['multiply'] = '*';
correspondingChar['division'] = '/';

function buttonProcessor(value){
    if ( isNum(value) ){

        viewOnScreen(value);
    } else if ( isOp(value)){

        viewOnScreen(correspondingChar[value]);
    } else if ( isClear(value) ){

        clearScreen();
    } else if ( isBackSpace(value) ){
        backSpaceOperation();
    }
}

function viewOnScreen(val){
    var textFieldVal = document.getElementById("input_editor_textfield").value;
    document.getElementById("input_editor_textfield").value = textFieldVal+val.toString();
    return;
}
function clearScreen(){
    document.getElementById("input_editor_textfield").value = "";
    return;
}
function backSpaceOperation(){
    var textFieldVal = document.getElementById("input_editor_textfield").value;
    document.getElementById("input_editor_textfield").value = textFieldVal.substring(0,textFieldVal.length-1);
    return;
}



function isNum(val){
    if (val >= 0 && val <= 9){
        return true;
    }
    return false;
}

function isOp(val){
    if (val=='plus' || val=='minus' || val=='multiply' || val=='division') return true;
    return false;
}

function isClear(val){
    if (val=='clear') return true;
    return false;
}

function isBackSpace(val){
    if (val=='back') return true;
    return false;
}