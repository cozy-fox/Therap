package com.company;


import java.util.Scanner;

public class Main {

    public static String searchCondition = "PROFILER";

    public static void main(String[] args) {

        MyParser myParseVar = new MyParser();

        System.out.print("Enter the URI: ");
        Scanner sc = new Scanner(System.in);
        String searchUri = sc.nextLine();

        System.out.print("Enter File Path: ");
        Scanner sc2 = new Scanner(System.in);
        String fileName = sc2.nextLine();

        String line = "";
        while ( (line = myParseVar.logInput(fileName)) != null){
            myParseVar.parseLog(searchUri, searchCondition, line);
        }

        myParseVar.logOutput("console");
    }
}
