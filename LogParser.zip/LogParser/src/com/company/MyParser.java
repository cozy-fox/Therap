package com.company;

import java.io.*;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: sanjoy.saha
 * Date: 4/6/14
 * Time: 11:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class MyParser implements LogFileIO {

    Map<String, Integer> occuranceMap    = new TreeMap<String, Integer>();
    Map<String, Integer> responseTimeMap = new TreeMap<String, Integer>();

    static InputStream inFile    = null;
    static BufferedReader reader = null;

    public String logInput(String fileName) {
        try {
            if (inFile == null) {
                inFile = new BufferedInputStream(new FileInputStream(fileName));
                reader = new BufferedReader(new InputStreamReader(inFile));
            }
            String str = "";

            if ((str   = reader.readLine()) != null) {
                return str;
            } else {
                inFile.close();
                return null;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;

    }

    public void parseLog(String uri, String condition, String inLine) {

        if (!inLine.contains(condition)) {
            return;
        } else {
            if (inLine.contains(uri)) {

                String[] parts   = inLine.split(" ");
                String timeStamp = parts[1];

                /**
                 * Get the index of the arrays
                 */
                String[] timeTmp = timeStamp.split(":");
                String indexString = timeTmp[0];
                String indexForMap = indexString + ":00:00";

                /**
                 * Parse the response time
                 */
                int responseTime        = 0;
                String regularEx        = "\\D+";
                String responseTimeStr  = parts[parts.length - 1];
                String timeSplitStr[]   = responseTimeStr.split(regularEx);

                for (String sss : timeSplitStr)
                    if (sss.matches("\\d+")) {
                        responseTime = Integer.parseInt(sss);
                    }

                /**
                 * Update the occurance count map
                 */
                if (occuranceMap.containsKey(indexForMap)) {
                    occuranceMap.put(indexForMap, occuranceMap.get(indexForMap) + 1);
                } else {
                    occuranceMap.put(indexForMap, 1);
                }

                /**
                 * Update the response time map
                 */
                if (responseTimeMap.containsKey(indexForMap)) {
                    responseTimeMap.put(indexForMap, responseTimeMap.get(indexForMap) + responseTime);
                } else {
                    responseTimeMap.put(indexForMap, 0);
                }
            }
        }
    }

    public void logOutput(String dest) {
        if (dest.equals("console")) {

            for (String key : occuranceMap.keySet()) {
                String hoursValue = key;
                Integer occuranceCount = occuranceMap.get(key);
                Integer responseTime = responseTimeMap.get(key);

                System.out.println("[" + key + "]+[00:59:59]\t" + occuranceCount + " hits\t" + responseTime + " ms (response time)");
            }
        }
    }
}
